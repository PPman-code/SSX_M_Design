# 界面与状态

以下来自 390 CSS px 宽、844 CSS px 高的桌面 Chrome 移动仿真，浅色，截图密度 2×。原型相对路由用于设计侧复现。开发侧可根据操作和数据描述在目标项目建立相同状态。

## 意向客户沟通页签

打开 /#/pages/customer-info/v1?customer=customer-1，使用新浏览器状态。默认样例包含 7 条待处理。

![意向客户沟通页签](customer.png)
